# Analytics API App
default_app_config = 'backend_analytics_api.apps.BackendAnalyticsApiConfig'